package esperanto;
import java.io.*;
import java.util.concurrent.TimeUnit;
class vocablo
{
 String espaniol;
 String euselengoa;
 String aleman;
 String ingles; // �Que me duelen las ingles!
 vocablo (String espaniol, String euselengoa, String aleman, String ingles)
 {
  this.espaniol = espaniol;
  this.euselengoa = euselengoa;
  this.aleman = aleman;
  this.ingles = ingles;
 }
}

class GlobalVals
{
 static int ultimocaracter;
 static vocablo[] tiempos = new vocablo[10];
 static vocablo[] pronombres = new vocablo[25];
 static vocablo[] preposiciones = new vocablo[25];
 static vocablo[] adverbios = new vocablo[25];
 static vocablo[] adjetivos = new vocablo[50];
 static vocablo[] verbos = new vocablo[75];
 static vocablo[] nombres = new vocablo[100];
 static int numtiempos = 0;
 static int numpronombres = 0;
 static int numpreposiciones = 0;
 static int numadverbios = 0;
 static int numadjetivos = 0;
 static int numverbos = 0;
 static int numnombres = 0;
}

public class Esperanto
{
 public static char readNext(Reader input) throws IOException 
 {
  int currentChar = input.read();
  //System.out.println(currentChar);
  return (char) currentChar;
 }   
 
 public static boolean noMoreChars(int caracter)
 {
  return ( (caracter == -1) || (caracter == 65535) );
 }
 
 static boolean estaen2(String lexema, vocablo v)
 {
  String aleman = v.aleman;
  String espaniol = v.espaniol;
  String ingles = v.ingles;
  String euselengoa = v.euselengoa;
  if (aleman.equalsIgnoreCase(lexema) || espaniol.equalsIgnoreCase(lexema) || 
      ingles.equalsIgnoreCase(lexema) || euselengoa.equalsIgnoreCase(lexema))
  return true;    
   else   
    return false;   
 }
 
 static boolean separece(String lexema, String lexemavocablo)
 {
  // Secuencia de pares de letras desde la primera hasta la pen�ltima.
  // Para cada una, se busca esta secuencia en la misma posici�n, o anterior o posterior. 
  // Si hay coincidencia, se suma  
  float parecido = 0; // Puede llegar cerca de 1.
  char[] lexemaArray = lexema.toCharArray();
  char[] lexemavocabloArray = lexemavocablo.toCharArray();
  float maximolexema;
  if (lexema.length() > lexemavocablo.length())
   maximolexema = lexema.length();
    else
     maximolexema = lexemavocablo.length();
  for (int i=1; i<lexema.length(); i++)
  {
   char caracter1 = lexemaArray[i-1];
   char caracter2 = lexemaArray[i];
   if (i < lexemavocablo.length())
   {
    boolean iguales = false;
    if ((lexemavocabloArray[i-1] == caracter1)
        && (lexemavocabloArray[i] == caracter2))
     iguales = true;
      else
       if ( (i > 1) && (lexemavocabloArray[i-2] == caracter1)
           && (lexemavocabloArray[i-1] == caracter2))
        iguales = true;
         else
         if ( (i < lexemavocablo.length() - 1) && (lexemavocabloArray[i] == caracter1)
             && (lexemavocabloArray[i+1] == caracter2))
          iguales = true;
    if (iguales == true) parecido = parecido + (1 / (maximolexema - 1));    
   }
  }
  if (parecido > 0.3)
  {
   System.out.print(parecido + " ");
   return true;
  } 
   else
    return false;
 }
 
 static boolean separecevocablo(String lexema, vocablo v)
 {
  if 
  (
   (lexema.length()>=2) &&
   (
    ((v.aleman.length()>=2) && (separece(lexema, v.aleman))) ||
    ((v.espaniol.length()>=2) && (separece(lexema, v.espaniol))) ||
    ((v.euselengoa.length()>=2) && (separece(lexema, v.euselengoa))) ||
    ((v.ingles.length()>=2) && (separece(lexema, v.ingles)))
   )
  )        
   return true;  
  return false;  
 }
 
 static void imprimirvocablo(vocablo v)
 {
  System.out.println(v.espaniol + " " + v.euselengoa + " " + v.aleman + " " + v.ingles);   
 }
 
 static boolean estaen(String lexema, vocablo[] diccionario, int numelem)
 {
  /*
   Recorremos diccionario, mientras no encontrado (esquema repetir,
   porque todos los elementos / vocablos se tratan igual).  
   Tiene que haber al menos un elemento en el diccionario.
  */
  boolean encontrado = false; // inicializar tratamiento
  int i = 0; // Inicializar tratamiento.
  vocablo vocabloaux;
  if (numelem > 0)
  {    
   do // El repeat de Java.
   {
    i++; // Obtener elemento siguiente
    vocabloaux = diccionario[i-1];
    if (estaen2(lexema, vocabloaux))
     encontrado = true;
      else
       if
               (separecevocablo(lexema, vocabloaux))    
        imprimirvocablo(vocabloaux);
   }
   while ((encontrado == false) && (i < numelem));
   if (encontrado == true) //sacar el vocablo por pantalla y retorna true
   {
    imprimirvocablo(vocabloaux);
    return true;   
   }
  }
  return false;   
 }
 
 public static int leer(Reader input) throws IOException// static, para ser bien referenciado
 {
  int caracter;
  while (true)
  {
   caracter = GlobalVals.ultimocaracter;
   while (Character.isWhitespace(caracter))   
    caracter = readNext(input);
	    
   if (noMoreChars(caracter))
    return 0;
   
   //Se trata simplemente de ir a�adiendo a un buffer mientras...
   StringBuffer buffer = new StringBuffer();
   buffer.append((char) caracter);
   caracter = readNext(input);
   while (!Character.isWhitespace(caracter) && !noMoreChars(caracter))
   {
    buffer.append((char) caracter);
    caracter = readNext(input);
   }
   
   GlobalVals.ultimocaracter = caracter;
   String lexeme = buffer.toString(); 
   System.out.println(lexeme);
   
   //Ver si es pronombre, nombre, adjetivo o infinitivo.
   // Entonces s� que se retorna 1. Si no, cero y error.
   // Faltar�a una funci�n que recorre un array de vocablos...
   /*
    A�adir al programa de "Esperanto a la luitisa" (para tus palabras que no se
    hayan encontrado en el diccionario): separas en grupos de 2 letras (cabeza =
    ca + ab + be + ez + za = 5). Por cada coincidencia en un vocablo (palabra en
    4 idiomas guardada), sumas 1 / 5, y si suma 50%, pones el vocablo, y sigues 
    buscando vocablos hasta el final.
   */
   if (estaen(lexeme, GlobalVals.tiempos, GlobalVals.numtiempos) == true) // Aqu� dentro ya sacamos por pantalla el vocablo.
    return 1;
   if (estaen(lexeme, GlobalVals.pronombres, GlobalVals.numpronombres) == true) // Aqu� dentro ya sacamos por pantalla el vocablo.
    return 1;
   if (estaen(lexeme, GlobalVals.preposiciones, GlobalVals.numpreposiciones) == true) // Aqu� dentro ya sacamos por pantalla el vocablo.
    return 1;
   if (estaen(lexeme, GlobalVals.adverbios, GlobalVals.numadverbios) == true) // Aqu� dentro ya sacamos por pantalla el vocablo.
    return 1;
   if (estaen(lexeme, GlobalVals.adjetivos, GlobalVals.numadjetivos) == true) // Aqu� dentro ya sacamos por pantalla el vocablo.
    return 1;
   if (estaen(lexeme, GlobalVals.verbos, GlobalVals.numverbos) == true) // Aqu� dentro ya sacamos por pantalla el vocablo.
    return 1;
   if (estaen(lexeme, GlobalVals.nombres, GlobalVals.numnombres) == true) // Aqu� dentro ya sacamos por pantalla el vocablo.
    return 1;
   return 1;
  }	        
 }
 
 static String leerlexema(Reader input, vocablo[] diccionario)
 {
  // El �ltimo car�cter, lo guardamos;
  // Habr�a sido quiz�s m�s f�cil con readline().
  String result = "";
  int caracter = 0;
  StringBuffer buffer = new StringBuffer();
  try
  {
   caracter = input.read();
   while (!Character.isWhitespace(caracter) && !noMoreChars(caracter))
   {
    buffer.append((char) caracter);
    caracter = input.read();
   }
  }
  catch (IOException e) {System.out.println(e);}
  
  if (buffer.length() > 0) result = buffer.toString(); 
  
  GlobalVals.ultimocaracter = caracter;
  //System.out.println(result);
  return result;
 }
 
 static int leerlinea(Reader input, vocablo[] diccionario, String nomdiccionario) throws IOException
 {
  //int caracter = input.read(); // Para las pruebas, algo hay que avanzar.
  int caracter = 0;
     
  int indice = 0; // Inicializamos para que el compilador no "grite" tanto.
  // �Habr�a valido con poner como par�metro una referencia a entero no?
  if (nomdiccionario.equals("nom"))
  {
   indice = GlobalVals.numnombres;
   GlobalVals.numnombres++;
   GlobalVals.nombres[indice] = new vocablo("","","","");
  }
  if (nomdiccionario.equals("adj"))
  {
   indice = GlobalVals.numadjetivos;
   GlobalVals.numadjetivos++;
   GlobalVals.adjetivos[indice] = new vocablo("","","","");
  }
  if (nomdiccionario.equals("pro"))
  {
   indice = GlobalVals.numpronombres;
   GlobalVals.numpronombres++;
   GlobalVals.pronombres[indice] = new vocablo("","","","");
  }
  if (nomdiccionario.equals("adv"))
  {
   indice = GlobalVals.numadverbios;
   GlobalVals.numadverbios++;
   GlobalVals.adverbios[indice] = new vocablo("","","","");
  }
  if (nomdiccionario.equals("ver"))
  {
   indice = GlobalVals.numverbos;
   GlobalVals.numverbos++;
   GlobalVals.verbos[indice] = new vocablo("","","","");
  }
  if (nomdiccionario.equals("pre"))
  {
   indice = GlobalVals.numpreposiciones;
   GlobalVals.numpreposiciones++;
   GlobalVals.preposiciones[indice] = new vocablo("","","","");
  }
  if (nomdiccionario.equals("tie"))
  {
   indice = GlobalVals.numtiempos;
   GlobalVals.numtiempos++;
   GlobalVals.tiempos[indice] = new vocablo("","","","");
  }
  
  String lexema = leerlexema(input, diccionario);
  if (lexema.equals(""))
  {
   diccionario[indice].aleman = "FALLONADA";
   diccionario[indice].espaniol = "FALLONADA";
   diccionario[indice].euselengoa = "FALLONADA";
   diccionario[indice].ingles = "FALLONADA";
  }
   else
   {
    diccionario[indice].espaniol = lexema;   
    lexema = leerlexema(input, diccionario);
    if (lexema.equals(""))
    {
     diccionario[indice].euselengoa = "FALLONADA";   
     diccionario[indice].aleman = "FALLONADA";     
     diccionario[indice].ingles = "FALLONADA";   
    }
     else
     {
      diccionario[indice].euselengoa = lexema;
      lexema = leerlexema(input, diccionario);
      if (lexema.equals(""))
      {   
       diccionario[indice].aleman = "FALLONADA";     
       diccionario[indice].ingles = "FALLONADA";   
      }
       else
       {
        diccionario[indice].aleman = lexema;
        lexema = leerlexema(input, diccionario);
        if (lexema.equals(""))
         diccionario[indice].ingles = "FALLONADA";   
          else
          {
           diccionario[indice].ingles = lexema;
           //�Mientras que el �ltimo caracter le�do no sea fin de l�nea o
           // fin de fichero, seguimos leyendo.
           // �C�mo obtenemos este �ltimo caracter?
           // �Poner el descriptor de lectura uno atr�s je je?
           caracter = GlobalVals.ultimocaracter;
           while ((caracter != 13) && (caracter != -1) && (caracter !=65535))
            caracter = input.read();
           if (caracter == 13) input.read();
          }
       }
     }
   }       
  //COMPROBAR QUE SE PASA POR REFERENCIA EL ARRAY.
  //diccionario[0].aleman = "ale";
  //diccionario[0].espaniol = "esp";
  //diccionario[0].euselengoa = "eus";
  //diccionario[0].ingles = "ing";  
  
  return caracter;
 }
 
 static void metervocablos(String fichero, vocablo[] diccionario, String nomdiccionario) throws IOException
 {   
  //Recibe un fichero donde en cada l�nea, hay 4 lexemas.
  int caracter;
  Reader input = new FileReader(fichero);
  do
  {
   caracter = leerlinea(input, diccionario, nomdiccionario);   
  }
  while ( (caracter != -1) && (caracter != 65535) );
 }
 
 public static void main(String[] args) throws IOException
 {
  GlobalVals.pronombres[GlobalVals.numpronombres++] = new vocablo("yo", "I", "ich", "I");
  //GlobalVals.nombres[GlobalVals.numnombres++] = new vocablo("berdad", "egi", "wahrheit", "truth");
  //COMPROBAR QUE SE PASA POR REFERENCIA EL ARRAY.
  //GlobalVals.nombres[0] = new vocablo("na", "na", "na", "na");
  //try {metervocablos("nombres.txt", GlobalVals.nombres, "nom");}
  //catch (IOException e) {System.out.println(e);}
  metervocablos("nombres.txt", GlobalVals.nombres, "nom");
  metervocablos("adjetivos.txt", GlobalVals.adjetivos, "adj");
  metervocablos("pronombres.txt", GlobalVals.pronombres, "pro");
  metervocablos("adverbios.txt", GlobalVals.adverbios, "adv");
  metervocablos("preposiciones.txt", GlobalVals.preposiciones, "pre");
  metervocablos("tiempos.txt", GlobalVals.tiempos, "tie");
  metervocablos("verbos.txt", GlobalVals.verbos, "ver");
  //System.out.println(GlobalVals.nombres[0].euselengoa);
  //System.out.println(GlobalVals.numnombres); // AQU� NO HAY REFERNCIA QUE VALGA.
  
  Reader r = new InputStreamReader(System.in);
  try
  {
   System.out.println(System.getProperty("user.dir")); // poner aqu� el .txt
   
   Reader input = new FileReader("zejemplo.txt");
   GlobalVals.ultimocaracter = readNext(input);
   while (leer(input) != 0) {}
  }
  catch (IOException e) {System.out.println(e);}
  try{TimeUnit.SECONDS.sleep(1);}
  catch (InterruptedException e){}
  System.out.println("Pulsa una tecla");
  r.read();
 }   
}
